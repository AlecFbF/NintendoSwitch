
var defaultClickURL = [
          {productLabel:"intro",productURL:"https://store.nintendo.co.uk/nintendo-switch.list"}
           ];

var WID = 300;
var HEI = 600;


